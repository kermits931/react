# VectorWidget example

To try this example, run:

```
yarn
yarn build
```

in this directory, then open index.html in your browser.
